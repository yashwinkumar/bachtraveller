<?php
/**
 * Created by PhpStorm.
 * User: me664
 * Date: 11/14/14
 * Time: 10:41 AM
 */

if(!class_exists('STAttribute')) return;

class AttributeMeta
{
    function init()
    {


    }


}

$a=new AttributeMeta();
$a->init();
